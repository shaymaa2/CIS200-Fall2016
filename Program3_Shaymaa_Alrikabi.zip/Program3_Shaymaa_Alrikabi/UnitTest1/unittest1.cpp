#include "stdafx.h"
#include "CppUnitTest.h"
#include"..\Program3_Shaymaa_Alrikabi\Ship.h"
#include"..\Program3_Shaymaa_Alrikabi\Battle.h"
#include"..\Program3_Shaymaa_Alrikabi\Corvette.h"
#include"..\Program3_Shaymaa_Alrikabi\Cruiser.h"
#include"..\Program3_Shaymaa_Alrikabi\Repair.h"
#include <string>
using namespace std;
using namespace Microsoft::VisualStudio::CppUnitTestFramework;
namespace UnitTest1
{		
	TEST_CLASS(UnitTest1)
	{
	public:
				TEST_METHOD(TestBattleship_attack)
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", 10, 15, us);
					fleet[1] = new Battle("Mrbeen", 9, 8, them);
					fleet[0]->attack(fleet[1]);
					outputval = fleet[0]->getCurrentHealth();
					expectedval = 100;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 80;
					Assert::AreEqual(expectedval, outputval);
				}

				
			
				TEST_METHOD(TestBattleship_attack_outofrange)
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", 10, 15, us);
					fleet[1] = new Battle("Mrbeen", 90, 8, them);
					fleet[0]->attack(fleet[1]);
					outputval = fleet[0]->getCurrentHealth();
					expectedval = 100;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 100;
					Assert::AreEqual(expectedval, outputval);
				}

				TEST_METHOD(TestBattleship_attack_chaoticship)
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -5, -3, us);
					fleet[1] = new Battle("Mrbeen", 2, 0, chaotic);
					fleet[0]->attack(fleet[1]);
					outputval = fleet[0]->getCurrentHealth();
					expectedval = 100;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 80;
					Assert::AreEqual(expectedval, outputval);
				}
				TEST_METHOD(TestBattleship_attack_chaoticship_attacking_chaotic)
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -5, -3, chaotic);
					fleet[1] = new Battle("Mrbeen", 2, 0, chaotic);
					fleet[0]->attack(fleet[1]);
					outputval = fleet[0]->getCurrentHealth();
					expectedval = 100;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 80;
					Assert::AreEqual(expectedval, outputval);
				}
				TEST_METHOD(TestCruiser_attack_inRange_checkhealth) //range is 50, maxHealth =50
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Cruiser("super", -5, -3, them);
					fleet[1] = new Cruiser("super", 10, 10, us);

					fleet[0]->attack(fleet[1]);
					outputval = fleet[1]->getCurrentHealth();
					expectedval = 45;
					Assert::AreEqual(expectedval, outputval);
					outputval = fleet[0]->getCurrentHealth();
					expectedval = 50;
					Assert::AreEqual(expectedval, outputval);
				}
				TEST_METHOD(TestCruiser_attack_inrange_moveoutrange_attackgain_checkhealth)
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Cruiser("super", -5, -3, them);
					fleet[1] = new Cruiser("super", 40, 18, us);

					fleet[0]->attack(fleet[1]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 50;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 45;
					Assert::AreEqual(expectedval, outputval);

					fleet[1]->move();
					fleet[0]->attack(fleet[1]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 50;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 46;
					Assert::AreEqual(expectedval, outputval);
				}
				TEST_METHOD(TestCruiser_attack_inrange_moveoutrange_attackgain_checkhealth_chaotic)
				{	// always moves along the vector (-1, -1)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Cruiser("super", -5, -3, chaotic);
					fleet[1] = new Cruiser("super", 40, 18, chaotic);

					fleet[0]->attack(fleet[1]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 50;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 45;
					Assert::AreEqual(expectedval, outputval);

					fleet[1]->move();
					fleet[0]->attack(fleet[1]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 50;
					Assert::AreEqual(expectedval, outputval);

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 46;
					Assert::AreEqual(expectedval, outputval);
				}
				TEST_METHOD(TestCorvette_locationx_y)
				{	// always moves along the vector (5, 5)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Corvette("super", -5, -3, them);

					outputval = fleet[0]->getX();
					expectedval = -5;
					Assert::AreEqual(expectedval, outputval);
					outputval = fleet[0]->getY();
					expectedval = -3;
					Assert::AreEqual(expectedval, outputval);
				}
				TEST_METHOD(TestCorvette_attack_inrange)
				{	// always moves along the vector (5, 5)
					Alignment outputval = us;
					Alignment expectedval = us;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -5, -3, us);
					fleet[1] = new Corvette("super", 1, 1, them);
					fleet[1]->attack(fleet[0]);

					outputval = fleet[0]->getAlign();
					expectedval = them;
					Assert::AreEqual(int(expectedval), int(outputval));

					outputval = fleet[1]->getAlign();
					expectedval = them;
					Assert::AreEqual(int(expectedval), int(outputval));
				}

				TEST_METHOD(TestCorvette_attack_inrange_chaotic)
				{	// always moves along the vector (5, 5)
					Alignment outputval = us;
					Alignment expectedval = us;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -5, -3, chaotic);
					fleet[1] = new Corvette("super", 1, 1, them);
					fleet[1]->attack(fleet[0]);

					outputval = fleet[0]->getAlign();
					expectedval = chaotic;
					Assert::AreEqual(int(expectedval), int(outputval));

					outputval = fleet[1]->getAlign();
					expectedval = them;
					Assert::AreEqual(int(expectedval), int(outputval));
				}

				TEST_METHOD(TestRepair_attack_inrange)
				{	// always moves along the vector (5, 5)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -5, -3, them);
					fleet[1] = new Repair("super", 1, 1, them);
					fleet[0]->setCurrentHealth(44);
					fleet[1]->attack(fleet[0]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 100;
					Assert::AreEqual(int(expectedval), int(outputval));

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 20;
					Assert::AreEqual(int(expectedval), int(outputval));
				}


				TEST_METHOD(TestRepair_attack_outofrange)
				{	// always moves along the vector (5, 5)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -555, -3, them);
					fleet[1] = new Repair("super", 1, 1, them);
					fleet[0]->setCurrentHealth(44);
					fleet[1]->attack(fleet[0]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 44;
					Assert::AreEqual(int(expectedval), int(outputval));

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 20;
					Assert::AreEqual(int(expectedval), int(outputval));
				}

				TEST_METHOD(TestRepair_attack_repairdeadship)
				{	// always moves along the vector (5, 5)
					int outputval = 0;
					int expectedval = 0;
					Ship** fleet;
					int numShip;
					numShip = 5;
					fleet = new Ship *[numShip];
					fleet[0] = new Battle("super", -5, -3, them);
					fleet[1] = new Repair("super", 1, 1, them);
					fleet[0]->setCurrentHealth(0);
					fleet[1]->attack(fleet[0]);

					outputval = fleet[0]->getCurrentHealth();
					expectedval = 0;
					Assert::AreEqual(int(expectedval), int(outputval));

					outputval = fleet[1]->getCurrentHealth();
					expectedval = 20;
					Assert::AreEqual(int(expectedval), int(outputval));
				}

	};
}