#include"..\Program3_Shaymaa_Alrikabi\Ship.h"
#include"..\Program3_Shaymaa_Alrikabi\Battle.h"
#include"..\Program3_Shaymaa_Alrikabi\Corvette.h"
#include"..\Program3_Shaymaa_Alrikabi\Cruiser.h"
#include"..\Program3_Shaymaa_Alrikabi\Repair.h"
#include <string>
#include<iostream>
using namespace std;

void main()
{

	int myshiphelath = 0;
	int enemyhealth = 0;


	int ships = 4;
	Ship **inABottle;
	inABottle = new Ship*[ships];
	inABottle[0] = new Battle("usBattleShip", 20, 20, us);
	inABottle[1] = new Battle("themBattleShip", 50, 50, them);
	inABottle[2] = new Cruiser("usCruiser", 10, 10, us);
	inABottle[3] = new Cruiser("themCruiser", 25, 25, them);


	for (int turn = 1; turn <= 10; turn++)
	{
		for (int attackerIndex = 0; attackerIndex < ships; attackerIndex++)
		{
			for (int targetIndex = 0; targetIndex < ships; targetIndex++)
			{
				 myshiphelath = inABottle[attackerIndex]->getCurrentHealth();
				 cout << "myship health " << attackerIndex << "  health " <<myshiphelath;
				enemyhealth = inABottle[targeIndex]->getCurrentHealth();
				cout << "myship health " << targeIndex << "  health " << enemyhealth;
				
				inABottle[attackerIndex]->attack(inABottle[targetIndex]);
				myshiphelath = inABottle[attackerIndex]->getCurrentHealth();
				enemyhealth = inABottle[targetIndex]->getCurrentHealth();



			}
			inABottle[attackerIndex]->move();
		}
	}





}