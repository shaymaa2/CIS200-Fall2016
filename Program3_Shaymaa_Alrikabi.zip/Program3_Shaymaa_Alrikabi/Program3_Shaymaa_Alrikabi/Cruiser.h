//Shaymaa alrikabi
#pragma once
#include "Ship.h"

class Cruiser : public Ship
{

public:
	Cruiser(string shipname, int x, int y, Alignment shipalign) :Ship(shipname, x, y, shipalign, 50, 50, 5)
	{

	}
	Cruiser(string shipname, int x, int y, Alignment shipalign, int RepairMaxHealth) :Ship(shipname, x, y, shipalign, RepairMaxHealth, 50, 5)
	{

	}
	//range is 50, maxhealth = 50
	// always moves along the vector (1, 2)
	void move()
	{
		int x = Ship::getX();  // get x location
		int y = Ship::getY();  //get y location

		Ship::setX(x + 1);
		Ship::setY(y + 2);

		if (getCurrentHealth() < getMaxHealth())
		{
			Ship::setCurrentHealth(Ship::getCurrentHealth() + 1);

		}

	}
	void attack(Ship *target) //attacks 5
	{
		double hypotenuse = hypot((getX() - target->getX()), (getY() - target->getY()));
		if (getAlign() != target->getAlign() || target->getAlign() == chaotic || getAlign() == chaotic)  //checking alignment , cant attack same alignment, chaotic attack everyone
		{
			if (hypotenuse <= 50 && target->getCurrentHealth()> 0 && getCurrentHealth()> 0)  // range for battle is 50, check health for attacker and target >0
			{
					target->setCurrentHealth(target->getCurrentHealth() - 5); // attack power is 10
			}

		}

	}
	string status() 
	{
		return "name: " + getName() + "\ntype: Cruiser" + "\nhealth: " + to_string(getCurrentHealth()) +
			"\nlocation: " + to_string(getX()) + to_string(getY());
	}

};

