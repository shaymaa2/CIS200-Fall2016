//#include <iostream>
//#include<string>
//#include "Battle.h"
//#include "Ship.h"
//using namespace std;
//
//int main()
//{
//	Ship** fleet;
//	int numShip;
//	//cout<<"How many ships do you want ?";
//	//cin>> numShip;
//	numShip = 6;
//	fleet = new Ship *[numShip];
//	fleet[0] = new Battle("Constitution", 0, 0, us);
//	//fleet[1] = new Cruiser("Enterprize", 20, 20, them);
//	//fleet[2] = new Corvette("1000Falcon", 0, 5, chaotic);
//	//fleet[3] = new Repair("DocMcStuffings", 5, 4, them);
//	//fleet[4] = new Battle("BoatyMcBoatFace", 3, 2, us);
//	//fleet[5] = new Corvette("Howdy2020", 5, 4, chaotic);
//
//	for (int i = 0; i < numShip; i++)
//		cout << fleet[i]->status() << endl;
//	//for (int i = 0; i < numShip; i++)
//	//	fleet[i]->move();
//	//for (int i = 0; i < numShip; i++)
//	//	cout << fleet[i]->status() << endl;
//	//for (int i = 0; i < numShip; i++)
//	//{
//	//	for (int j = 0; j < numShip; j++)
//	//		fleet[i]->attack(fleet[j]);
//	//}
//	//for (int i = 0; i < numShip; i++)
//	//	cout << fleet[i]->status() << endl;
//
//
//
//	return 0;
//	system("pause");
//}