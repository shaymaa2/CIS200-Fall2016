//shaymaa Alrikabi
#pragma once
#include "Ship.h"
#include  <string>
#include <cmath>
using namespace std;

class Corvette : public Ship
{

public:
	//range is 25, maxHealth = 20
	// always moves along the vector (5, 5)
	Corvette(string shipName, int x, int y, Alignment shipAlign) :Ship(shipName, x, y, shipAlign,20,25,0)
	{

	}
	void move()
	{
		int x = Ship::getX();  // get x location
		int y = Ship::getY();  //get y location

		Ship::setX(x + 5);
		Ship::setY(y + 5);

		if (getCurrentHealth() < getMaxHealth())
		{
			Ship::setCurrentHealth(Ship::getCurrentHealth() + 1);

		}


	}
	void attack(Ship *target)// Everyone loves corvettes so their attack
							// flips ships in range to its state (if self is us, turns them to us,if self is them, turns us to them)
	{
		double hypotenuse = hypot((getX() - target->getX()), (getY() - target->getY()));

		if (hypotenuse <= 25 && target->getCurrentHealth()> 0 && getCurrentHealth()> 0)
		{
			if (getAlign() != chaotic && target->getAlign() != chaotic && getAlign() != target->getAlign())
			{
				target->changeAlign();
			}

		}
	}
	string status()
	{
		return "name: " + getName() + "\nType: Corvette" + "\nHealth: " + to_string(getCurrentHealth()) +
			"\nLocation: " + to_string(getX()) + to_string(getY());
	}


};