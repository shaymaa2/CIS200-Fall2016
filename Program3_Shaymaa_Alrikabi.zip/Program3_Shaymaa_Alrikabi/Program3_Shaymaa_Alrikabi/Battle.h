//Shaymaa Alrikabi
#pragma once
#include "Ship.h"
#include  <string>
#include <cmath>
using namespace std;

class Battle : public Ship
{
 //range is 10, maxHealth =100 ,attack = 10
protected:
	int torpedoes; // int initially 10
		
public:		
	Battle(string shipName, int x, int y, Alignment shipAlign):Ship(shipName, x, y, shipAlign, 100, 10, 10),torpedoes(10)
	{
	
	}
	 // always moves along the vector (-1, -1), increase health +1 for every move
	void move()
	{
		int x = Ship::getX();  // get x location
		int y = Ship::getY();  //get y location

		Ship::setX(x - 1);
		Ship::setY(y- 1);
		if (getCurrentHealth() < getMaxHealth() )
		{
			Ship::setCurrentHealth(Ship::getCurrentHealth() + 1);

		}
	}
	void attack(Ship *target) //attacks and fires torpedo >0 and
							 // does additional 10 damage, 1 less torpedo
	{
		double hypotenuse = hypot((getX() - target->getX()), (getY() - target->getY()));
		if (getAlign() != target->getAlign() || target->getAlign() == chaotic || getAlign() == chaotic)  //checking alignment , cant attack same alignment, chaotic attack everyone
		{
			if (hypotenuse <= 10 && target->getCurrentHealth()> 0 && getCurrentHealth()> 0)  // range for battle is 10, check health for attacker and target >0
			{
				if (torpedoes > 0)  // torpedo 10
				{
					target->setCurrentHealth(target->getCurrentHealth() - 20);// attack power of torpedo is 20
				}
				else
				{
					target->setCurrentHealth(target->getCurrentHealth() - 10); //when running out of torpedo attack power is 10
				}
				torpedoes--;

			}

		}
	}
	string status() // also indicates number of torpedoes
	{
		return "name: " + getName() + "\nType: Battle" + "\nHealth: " + to_string(getCurrentHealth()) +
			"\nLocation: " + to_string(getX()) + to_string(getY()) + "\nTorpedo: " + to_string(getTorpedo());
	}

	int getTorpedo()
	{
		return torpedoes;
	}
	void setTorpedo(int battleTorpedo)
	{
		torpedoes = battleTorpedo;
	}
};