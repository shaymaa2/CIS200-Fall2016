//Shaymaa Alrikabi
//CIS 200
//Program 3 TrekWars
//Description : the purpose of this program is learning to use classes, inheritance, class diagrams
//	, and virtual functions.Class Ship is the base class and classes Battle, Cruiser and Corvette
//	inherit from ship and finally class repair will inherit from cruiser.
//	Pre - condition : (what must be true for functions to run)
//	Ship : this is the base class, current health for this ship is set to max health which is specified by
//	the derived classes.Range and attack power is set by derived classes.Move and attack and
//	getType must be virtual so derived classes can modify as necessery.
//	Battle ship : must move in(-1, -1), battle ship will reduce the target health by 20 when using up
//	the 10 torpedoes and reduce by 10 without torpedo if  target is of opposite kind with health >0
//	and within range of 10. Battle ship health is between 0 - 100.
//	Range to attack must be within 10.
//	Max health of battle ships must be between 0 - 100.
//	Attack power with torpedo 20, without 10.
//	Torpedoes provided 10 and decrement when used.
//	Target must be of opposite kind and not dead(health >0).
//	Cruiser ship : must move in(1, 2), cruiser ship will reduce the target health by 5 if target is of
//	opposite kind with health > 0, and within range of 50. Cruiser ship health is between 0 - 50.
//	Range to attack must be within 50.
//	Max health of cruiser ship must between 0 - 50.
//	Attack power is 5.
//	Corvette ship : must move in(5, 5), corvette ship will flip target if target is of opposite kind and
//	health > 0 and within range of 25. Corvette health is between 0 - 20.
//	Range to attack must be within 25.
//	Max health of cruiser ship must between 0 - 20.
//	Attack power is to flip target to own kind.
//	Repair ship : derived from cruiser, if target from own kind and health <  max health & within
//	range of 25, Repair ship will restore target health to it�s maximum.
//	Post - condition : (what will be true after the functions are run)
//	Ships health increase by 1 for each move.
//	Battle Attack : will reduce target health by 20 when using the 10 torpedoes and reduce by 10
//	after running out of torpedo.
//	Cruiser Attack will reduce target health by 5.
//	Corvette Attack will flip target to own kind.
//	Repair Attack will restore target of own kind to max health.
#pragma once
#include <iostream>
#include <string>

using namespace std;
enum Alignment { us, them, chaotic };
class Ship
{
private:
	string name;
	Alignment align;
	int xLoc;
	int yLoc;
	int range;
	int currHealth;
	int attackPower;
	int maxHealth;
	string shipType;

public:
	Ship(string shipName,int x, int y , Alignment shipAlign, int maxHeal, int rng, int attackPwr)
	// currHealth is set to maximum
	{
		name = shipName;
		xLoc= x;
		yLoc = y;
		align = shipAlign;
		maxHealth=maxHeal ;
		range = rng;
		attackPower= attackPwr ;
		currHealth= maxHealth;

	}
	void virtual attack(Ship *target) 
	{
	}
	
	string virtual getType() //''Battleship'', ''Cruiser'', ''Corvette'', ''Repairship''
	{
		return shipType;
	}
	int getX() // returns the x coordinate
	{
		return xLoc;
	}
	void setX(int x)
	{
		xLoc = x;
	}
	int getY() // returns the y coordinate
	{
		return yLoc;
	}
	void setY(int y)
	{
		yLoc = y;
	}
	Alignment getAlign() // returns the alignment
	{
		return align;
	}

	virtual string status() // see format below  //TODO*****************************
	{
		return "name: " + getName() + "\nType: Battle" + "\nHealth: " + to_string(getCurrentHealth()) +
			"\nLocation: " + to_string(getX()) + to_string(getY());

	}
	void virtual move()  // changes position by the amount of that type of ship,
						// increases health by 1 (until max reached)
	{

	}
	void changeAlign() // changes the alignment.
	{
		if (getAlign()== us)   //flip alignment
		{
			align = them;
		}
		else
		{
			align = us;
		}
	}
	void assessDamage(int amt) // changes the health by amt,
							// (keeping it within bounds [0,maxHealth])
	{
		if (currHealth >= 0 && currHealth <= maxHealth)
		{
			currHealth = currHealth - amt; //TODO
		}
	}
	int getCurrentHealth()
	{
		return currHealth;
	}
	void setCurrentHealth(int health)
	{
		currHealth = health;
	}
	string getName()
	{
		return name;
	}
	void setMaxHealth()
	{
		currHealth = maxHealth;
	}
	int getMaxHealth()
	{
		return maxHealth;
	}
};