//Shaymaa Alrikabi
#pragma once
#include "Cruiser.h"
#include  <string>
#include <cmath>

using namespace std;

class Repair : public Cruiser
{

public:
	Repair(string shipName, int x, int y, Alignment shipAlign) : Cruiser(shipName, x, y, shipAlign,20)
	{
	
	}
	//range is 25, maxHealth = 20
	void attack(Ship *target) //	
	{
		double hypotenuse = hypot((getX() - target->getX()), (getY() - target->getY()));

		if (target->getAlign()== getAlign() && target->getCurrentHealth()>0 && getCurrentHealth()> 0 && hypotenuse <= 25)
		{
			target->setMaxHealth();
		}


	}
	string status()
	{
		return "name: " + getName() + "\nType: Repair" + "\nHealth: " + to_string(getCurrentHealth()) +
			"\nLocation: " + to_string(getX()) + to_string(getY());
	}

};
